package model.orm;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;

import model.data.Operation;
import model.orm.exception.DataAccessException;
import model.orm.exception.DatabaseConnexionException;
import model.orm.exception.ManagementRuleViolation;
import model.orm.exception.Order;
import model.orm.exception.RowNotFoundOrTooManyRowsException;
import model.orm.exception.Table;

public class AccessOperation {

	public AccessOperation() {
	}

	/**
	 * Recherche de toutes les op�rations d'un compte.
	 *
	 * @param idNumCompte id du compte dont on cherche toutes les op�rations
	 * @return Toutes les op�rations du compte, liste vide si pas d'op�ration
	 * @throws DataAccessException
	 * @throws DatabaseConnexionException
	 */
	public ArrayList<Operation> getOperations(int idNumCompte) throws DataAccessException, DatabaseConnexionException {
		ArrayList<Operation> alResult = new ArrayList<>();

		try {
			Connection con = LogToDatabase.getConnexion();
			String query = "SELECT * FROM Operation where idNumCompte = ?";
			query += " ORDER BY dateOp";

			PreparedStatement pst = con.prepareStatement(query);
			pst.setInt(1, idNumCompte);

			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				int idOperation = rs.getInt("idOperation");
				double montant = rs.getDouble("montant");
				Date dateOp = rs.getDate("dateOp");
				Date dateValeur = rs.getDate("dateValeur");
				int idNumCompteTrouve = rs.getInt("idNumCompte");
				String idTypeOp = rs.getString("idTypeOp");

				alResult.add(new Operation(idOperation, montant, dateOp, dateValeur, idNumCompteTrouve, idTypeOp));
			}
			rs.close();
			pst.close();
			return alResult;
		} catch (SQLException e) {
			throw new DataAccessException(Table.Operation, Order.SELECT, "Erreur acc�s", e);
		}
	}

	/**
	 * Recherche d'une op�ration par son id.
	 *
	 * @param idOperation id de l'op�ration recherch�e (cl� primaire)
	 * @return une Operation ou null si non trouv�
	 * @throws RowNotFoundOrTooManyRowsException
	 * @throws DataAccessException
	 * @throws DatabaseConnexionException
	 */
	public Operation getOperation(int idOperation)
			throws RowNotFoundOrTooManyRowsException, DataAccessException, DatabaseConnexionException {
		Operation operationTrouvee;

		try {
			Connection con = LogToDatabase.getConnexion();
			String query = "SELECT * FROM Operation  where" + " idOperation = ?";

			PreparedStatement pst = con.prepareStatement(query);
			pst.setInt(1, idOperation);

			ResultSet rs = pst.executeQuery();

			if (rs.next()) {
				int idOperationTrouve = rs.getInt("idOperation");
				double montant = rs.getDouble("montant");
				Date dateOp = rs.getDate("dateOp");
				Date dateValeur = rs.getDate("dateValeur");
				int idNumCompteTrouve = rs.getInt("idNumCompte");
				String idTypeOp = rs.getString("idTypeOp");

				operationTrouvee = new Operation(idOperationTrouve, montant, dateOp, dateValeur, idNumCompteTrouve,
						idTypeOp);
			} else {
				rs.close();
				pst.close();
				return null;
			}

			if (rs.next()) {
				rs.close();
				pst.close();
				throw new RowNotFoundOrTooManyRowsException(Table.Operation, Order.SELECT,
						"Recherche anormale (en trouve au moins 2)", null, 2);
			}
			rs.close();
			pst.close();
			return operationTrouvee;
		} catch (SQLException e) {
			throw new DataAccessException(Table.Operation, Order.SELECT, "Erreur acc�s", e);
		}
	}

	/**
	 * Enregistrement d'un d�bit.
	 *
	 * Se fait par proc�dure stock�e : - V�rifie que le d�bitAutoris� n'est pas
	 * d�pass� - Enregistre l'op�ration - Met � jour le solde du compte.
	 *
	 * @param idNumCompte compte d�bit�
	 * @param montant     montant d�bit�
	 * @param typeOp      libell� de l'op�ration effectu�e (cf TypeOperation)
	 * @throws RowNotFoundOrTooManyRowsException
	 * @throws DataAccessException
	 * @throws DatabaseConnexionException
	 * @throws ManagementRuleViolation
	 */
	public void insertDebit(int idNumCompte, double montant, String typeOp)
			throws DatabaseConnexionException, ManagementRuleViolation, DataAccessException {
		try {
			Connection con = LogToDatabase.getConnexion();
			CallableStatement call;

			String q = "{call Debiter (?, ?, ?, ?)}";
			// les ? correspondent aux param�tres : cf. d�f proc�dure (4 param�tres)
			call = con.prepareCall(q);
			// Param�tres in
			call.setInt(1, idNumCompte);
			// 1 -> valeur du premier param�tre, cf. d�f proc�dure
			call.setDouble(2, montant);
			call.setString(3, typeOp);
			// Param�tres out
			call.registerOutParameter(4, java.sql.Types.INTEGER);
			// 4 type du quatri�me param�tre qui est d�clar� en OUT, cf. d�f proc�dure

			call.execute();

			int res = call.getInt(4);

			if (res != 0) { // Erreur applicative
				throw new ManagementRuleViolation(Table.Operation, Order.INSERT,
						"Erreur de r�gle de gestion : d�couvert autoris� d�pass�", null);
			}
		} catch (SQLException e) {
			throw new DataAccessException(Table.Operation, Order.INSERT, "Erreur acc�s", e);
		}
	}
	
	/**
	 *  Enregistrement d'un Cr�dit.
	 *  
	 *  Enregistre l'op�ration - Met � jour le solde du compte.
	 * 
	 * @param idNumCompte	compte cr�dit�
	 * @param montant	montant cr�dit�
	 * @param typeOp	libell� de l'op�ration effectu�e (cf TypeOperation)
	 * @throws DatabaseConnexionException
	 * @throws ManagementRuleViolation
	 * @throws DataAccessException
	 */

	public void insertCredit(int idNumCompte, double montant, String typeOp)
			throws DatabaseConnexionException, ManagementRuleViolation, DataAccessException {
		try {
			Connection con = LogToDatabase.getConnexion();
			CallableStatement call;

			String q = "{call Crediter (?, ?, ?, ?)}";
			// les ? correspondent aux param�tres : cf. d�f proc�dure (4 param�tres)
			call = con.prepareCall(q);
			// Param�tres in
			call.setInt(1, idNumCompte);
			// 1 -> valeur du premier param�tre, cf. d�f proc�dure
			call.setDouble(2, montant);
			call.setString(3, typeOp);
			// Param�tres out
			call.registerOutParameter(4, java.sql.Types.INTEGER);
			// 4 type du quatri�me param�tre qui est d�clar� en OUT, cf. d�f proc�dure

			call.execute();

			int res = call.getInt(4);

			if (res != 0) { // Erreur applicative
				throw new ManagementRuleViolation(Table.Operation, Order.INSERT,
						"Erreur de r�gle de gestion : d�couvert autoris� d�pass�", null);
			}
		} catch (SQLException e) {
			throw new DataAccessException(Table.Operation, Order.INSERT, "Erreur acc�s", e);
		}
	}

	/**
	 * Fonction utilitaire qui retourne un ordre sql "to_date" pour mettre une date
	 * dans une requ�te sql
	 *
	 * @param d Date (java.sql) � transformer
	 * @return Une chaine : TO_DATE ('j/m/a', 'DD/MM/YYYY') 'j/m/a' : jour mois an
	 *         de d ex : TO_DATE ('25/01/2019', 'DD/MM/YYYY')
	 */
	private String dateToString(Date d) {
		String sd;
		Calendar cal;
		cal = Calendar.getInstance();
		cal.setTime(d);
		sd = "" + cal.get(Calendar.DAY_OF_MONTH) + "/" + (cal.get(Calendar.MONTH) + 1) + "/" + cal.get(Calendar.YEAR);
		sd = "TO_DATE( '" + sd + "' , 'DD/MM/YYYY')";
		return sd;
	}

}
