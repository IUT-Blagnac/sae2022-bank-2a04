package model.orm.exception;

/**
 * Ordres (op�rations) possibles sur la base de donn�es
 */
public enum Order {

	SELECT, UPDATE, DELETE, INSERT,

	OTHER // En g�n�ral, acc�s � la BD (type connexion ...)
}
