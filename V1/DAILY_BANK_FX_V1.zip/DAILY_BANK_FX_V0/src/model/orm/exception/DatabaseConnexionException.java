package model.orm.exception;

/**
 * Erreur de connexion � la bd. Impossible d'�tablir une connexion sur la bd.
 */

@SuppressWarnings("serial")
public class DatabaseConnexionException extends ApplicationException {

	public DatabaseConnexionException(String message, Throwable e) {
		super(Table.NONE, Order.OTHER, message, e);
	}
}