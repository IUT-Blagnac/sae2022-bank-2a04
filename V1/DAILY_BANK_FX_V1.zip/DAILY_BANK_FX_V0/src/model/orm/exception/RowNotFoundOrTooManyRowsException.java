package model.orm.exception;

/**
 * Erreur applicative sur un ordre select/insert/update/delete "monoligne".
 * L'ordre ex�cut� devait "traiter" une seule ligne et le r�sultat aboutit � 0
 * ou plusieurs lignes. Exemple de use case de survenue : - demande d'un update
 * d'un client � partir de son num�ro - le num�ro inexistant en base - => 0
 * lignes updat�es
 */

@SuppressWarnings("serial")
public class RowNotFoundOrTooManyRowsException extends ApplicationException {

	protected int rowsConcerned;

	/**
	 * @param tablename     nom de la table concern�e
	 * @param order         op�ration ayant �chou� sur tablename
	 * @param message       message associ� � l'erreur
	 * @param cause         �ventuelle autre Exception associ�e (en cas de
	 *                      SQLException principalement)
	 * @param rowsConcerned nombre de lignes concern�es (0 ou >1)
	 */
	public RowNotFoundOrTooManyRowsException(Table tablename, Order order, String message, Throwable cause,
			int rowsConcerned) {
		super(tablename, order, message, cause);
		this.rowsConcerned = rowsConcerned;
	}

	@Override
	public String getMessage() {
		return super.getMessageAlone() + " (" + this.tablename + " - " + this.order + " - " + "(" + this.rowsConcerned
				+ " rows)" + " - " + this.getCause() + ")";
	}

	public int getRowsConcerned() {
		return this.rowsConcerned;
	}
}
