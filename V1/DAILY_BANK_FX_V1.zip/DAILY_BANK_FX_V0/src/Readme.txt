


Pour pouvoir lancer l'application : modifier :
	dans Classe model.orm.LogToDatabase
		ajuster les valeurs des champs user et passwd pour votre groupe

Sinon l'application d�marrera mais se mettra en erreur au premier acc�s � la base de donn�es.

Il faudra aussi jouer le script de cr�ation de la BD.