package application.view;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import application.DailyBankState;
import application.control.EmployesManagement;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import model.data.Employe;

public class EmployeManagementController implements Initializable {

	// Etat application
	private DailyBankState dbs;
	private EmployesManagement cm;

	// Fenêtre physique
	private Stage primaryStage;

	// Données de la fenêtre
	private ObservableList<Employe> olc;

	// Manipulation de la fen�tre
	public void initContext(Stage _primaryStage, EmployesManagement _cm, DailyBankState _dbstate) {
		this.cm = _cm;
		this.primaryStage = _primaryStage;
		this.dbs = _dbstate;
		this.configure();
	}

	private void configure() {
		this.primaryStage.setOnCloseRequest(e -> this.closeWindow(e));

		this.olc = FXCollections.observableArrayList();
		this.lvEmploye.setItems(this.olc);
		this.lvEmploye.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
		this.lvEmploye.getFocusModel().focus(-1);
		this.lvEmploye.getSelectionModel().selectedItemProperty().addListener(e -> this.validateComponentState());
		this.validateComponentState();
	}

	public void displayDialog() {
		this.primaryStage.showAndWait();
	}

	// Gestion du stage
	private Object closeWindow(WindowEvent e) {
		this.doCancel();
		e.consume();
		return null;
	}

	// Attributs de la scene + actions
	@FXML
	private TextField txtLogin;
	@FXML
	private TextField txtMotDePasse;
	@FXML
	private ListView<Employe> lvEmploye;
	@FXML
	private Button btnDesactEmploye;
	@FXML
	private Button btnModifEmploye;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		txtLogin.setOnKeyPressed(event -> bouttonEntree(event,0) );
		txtMotDePasse.setOnKeyPressed(event -> bouttonEntree(event,1));
	}

	private void bouttonEntree(KeyEvent event,int val) {
		if (event.getCode().equals(KeyCode.ENTER)) {
			if (val == 0) {
				txtMotDePasse.requestFocus();
			} else {
				doRechercher();
			}
		}
	}

	@FXML
	private void doCancel() {
		this.primaryStage.close();
	}

	@FXML
	private void doRechercher() {
		int idEmploye;
		String nc = this.txtLogin.getText();
		String mdp = this.txtMotDePasse.getText();
		try {
			if (nc.equals("") || mdp.equals("")) {
				idEmploye = -1;
			} else {
				idEmploye = Integer.parseInt(nc);
				if (idEmploye < 0) {
					this.txtLogin.setText("");
					this.txtMotDePasse.setText("");
					idEmploye = -1;
				}
			}
		} catch (NumberFormatException nfe) {
			this.txtLogin.setText("");
			this.txtMotDePasse.setText("");
			idEmploye = -1;
		}

		if (idEmploye != -1) {
			this.txtLogin.setText("");
			this.txtMotDePasse.setText("");
		} else {
			if (nc.equals("") && !mdp.equals("")) {
				this.txtMotDePasse.setText("");
			}
		}

		// Recherche des clients en BD. cf. AccessClient > getClients(.)
		// idEmploye != -1 => recherche sur idEmploye
		// idEmploye != -1 et debutNom non vide => recherche nom/prenom
		// idEmploye != -1 et debutNom vide => recherche tous les clients
		ArrayList<Employe> listeCli = this.cm.getlisteComptes(idEmploye, nc, mdp);

		this.olc.clear();
		for (Employe cli : listeCli) {
			this.olc.add(cli);
		}

		this.validateComponentState();
	}

//	@FXML
//	private void doComptesClient() {
//		int selectedIndice = this.lvEmploye.getSelectionModel().getSelectedIndex();
//		if (selectedIndice >= 0) {
//			Client client = this.olc.get(selectedIndice);
//			this.cm.gererComptesClient(client);
//		}
//	}

	@FXML
	private void doModifierEmploye() {

		int selectedIndice = this.lvEmploye.getSelectionModel().getSelectedIndex();
		if (selectedIndice >= 0) {
			Employe cliMod = this.olc.get(selectedIndice);
			Employe result = this.cm.modifierEmploye(cliMod);
			if (result != null) {
				this.olc.set(selectedIndice, result);
			}
		}
	}

	@FXML
	private void doDesactiverEmploye() {
	}

	@FXML
	private void doNouveauEmploye() {
		Employe employe;
		employe = this.cm.nouveauEmploye();
		if (employe != null) {
			this.olc.add(employe);
		}
	}

	private void validateComponentState() {
		// Non implémenté => désactivé
		this.btnDesactEmploye.setDisable(true);
		int selectedIndice = this.lvEmploye.getSelectionModel().getSelectedIndex();
		if (selectedIndice >= 0) {
			this.btnModifEmploye.setDisable(false);
		} else {
			this.btnModifEmploye.setDisable(true);
		}
	}
}
