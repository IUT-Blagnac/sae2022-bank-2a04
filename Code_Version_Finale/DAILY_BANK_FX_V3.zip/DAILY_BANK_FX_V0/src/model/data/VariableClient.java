package model.data;

public class VariableClient {
	public static String nom;
}
