package application.view;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.ResourceBundle;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

import application.DailyBankState;
import application.control.ChoisirDossierPDF;
import application.control.OperationsManagement;
import application.tools.NoSelectionModel;
import application.tools.PairsOfValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.MenuItem;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import model.data.Client;
import model.data.CompteCourant;
import model.data.Operation;
import model.data.VariableClient;
import model.orm.exception.DataAccessException;
import model.orm.exception.DatabaseConnexionException;

public class OperationsManagementController implements Initializable {

	// Etat application
	private DailyBankState dbs;
	private OperationsManagement om;

	// Fenêtre physique
	private Stage primaryStage;

	// Données de la fenêtre
	private Client clientDuCompte;
	private CompteCourant compteConcerne;
	private ObservableList<Operation> olOperation;
	private ChoisirDossierPDF cdPDF;

//	public static String chemin;

	// Manipulation de la fenêtre
	public void initContext(Stage _primaryStage, OperationsManagement _om, DailyBankState _dbstate, Client client,
			CompteCourant compte) {
		this.primaryStage = _primaryStage;
		this.dbs = _dbstate;
		this.om = _om;
		this.clientDuCompte = client;
		this.compteConcerne = compte;
		this.configure();
	}

	private void configure() {
		this.primaryStage.setOnCloseRequest(e -> this.closeWindow(e));

		this.olOperation = FXCollections.observableArrayList();
		this.lvOperations.setItems(this.olOperation);
		this.lvOperations.setSelectionModel(new NoSelectionModel<Operation>());
		this.updateInfoCompteClient();
		this.validateComponentState(false);
	}

	public void displayDialog() {

		miseEnPlacePFD();
		if (compteConcerne.estCloture.compareTo("O") == 0) {
			this.validateComponentState(true);
		}
		this.primaryStage.showAndWait();
	}

	// Gestion du stage
	private Object closeWindow(WindowEvent e) {
		this.doCancel();
		e.consume();
		return null;
	}

	// Attributs de la scene + actions
	@FXML
	private Label lblInfosClient;
	@FXML
	private Label lblInfosCompte;
	@FXML
	private ListView<Operation> lvOperations;
	@FXML
	private Button btnDebit;
	@FXML
	private Button btnCredit;

	@FXML
	public Button btnVirement;

	@FXML
	private MenuItem janvier, fevrier, mars, avril, mai, juin, juillet, aout, septembre, octobre, novembre, decembre;

	@Override
	public void initialize(URL location, ResourceBundle resources) {

		janvier.setOnAction(e -> doGenererPDF(1, "Janvier"));
		fevrier.setOnAction(e -> doGenererPDF(2, "fevrier"));
		mars.setOnAction(e -> doGenererPDF(3, "mars"));
		avril.setOnAction(e -> doGenererPDF(4, "avril"));
		mai.setOnAction(e -> doGenererPDF(5, "mai"));
		juin.setOnAction(e -> doGenererPDF(6, "juin"));
		juillet.setOnAction(e -> doGenererPDF(7, "juillet"));
		aout.setOnAction(e -> doGenererPDF(8, "aout"));
		septembre.setOnAction(e -> doGenererPDF(9, "septembre"));
		octobre.setOnAction(e -> doGenererPDF(10, "octobre"));
		novembre.setOnAction(e -> doGenererPDF(11, "novembre"));
		decembre.setOnAction(e -> doGenererPDF(12, "decembre"));
	}

	/**
	 * Permet d'afficher les mois qui sont contenue dans la liste sur le menu.
	 * ex: 1 == janvier donc affichage ON
	 */
	private void miseEnPlacePFD() {
		int taille = lvOperations.getItems().size();
		for (int i = 0; i < taille; i++) {
			Date d = lvOperations.getItems().get(i).dateOp;
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(d);

			int mois = calendar.get(Calendar.MONTH) + 1;
			if (mois == 1)
				janvier.setVisible(true);
			if (mois == 2)
				fevrier.setVisible(true);
			if (mois == 3)
				mars.setVisible(true);
			if (mois == 4)
				avril.setVisible(true);
			if (mois == 5)
				mai.setVisible(true);
			if (mois == 6)
				juin.setVisible(true);
			if (mois == 7)
				juillet.setVisible(true);
			if (mois == 8)
				aout.setVisible(true);
			if (mois == 9)
				septembre.setVisible(true);
			if (mois == 10)
				octobre.setVisible(true);
			if (mois == 11)
				novembre.setVisible(true);
			if (mois == 12)
				decembre.setVisible(true);
		}
	}
/**
 * Ferme la fenêtre
 */
	@FXML
	private void doCancel() {
		this.primaryStage.close();
	}
	
	/**
	 * Génération du PDF en utilisant la librairie Itext
	 * Mais sur le pdf que les transactions faites durant le mois choisis
	 * 
	 * @param numMois Int permet de connaitre le mois choisis
	 * @param mois String Pour afficher dans le nom du fichier créer le mois
	 */

	private void doGenererPDF(int numMois, String mois) {

		cdPDF = new ChoisirDossierPDF(this.primaryStage, this.dbs);
		String chemin = cdPDF.doOperationsManagementDialog();

		if (chemin.length()== 0) {
			return;
		}
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");

		Document document = new Document(PageSize.A4);
//		String chemin = "C:\\Users\\boubo\\OneDrive\\Bureau\\Bureau\\programmation\\IUTJavaFX\\";
		chemin += "\\" + VariableClient.nom;
		chemin += " " + mois;
		chemin += ".pdf";

		try {
			PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(chemin));
			writer.setViewerPreferences(PdfWriter.PageLayoutSinglePage | PdfWriter.PageModeUseThumbs);

			document.open();
			try {

//				File fi = new File("logo.png");
//				System.out.println(fi.getAbsolutePath());//				
//				byte[] tab = Files.readAllBytes(fi.toPath());
				URL url = new URL("https://previews.123rf.com/images/sylverarts/sylverarts1701/sylverarts170100132/68942839-banque-logo-conceptuel-symbole-de-vecteur-unique-syst%C3%A8me-bancaire-.jpg");
		
		
				Image img = Image.getInstance(url);
				
				img.scaleToFit(100, 100);
				document.add(img);

			} catch (Exception x) {
				x.printStackTrace();
			}
			Font base = FontFactory.getFont(FontFactory.COURIER, 12);

			Paragraph Nom = new Paragraph("M./Mme " + VariableClient.nom);
			Nom.add("\n\r Date impression : " + dtf.format(LocalDateTime.now()));
			Nom.setAlignment(Element.ALIGN_RIGHT);

			Paragraph paragraph = new Paragraph("\n\r Bilan des transactions du mois de " + mois + " \n\r");
			paragraph.add("Solde Actuel : " + this.compteConcerne.solde + "€ \n\r\n\r\n\r");
			paragraph.setAlignment(Element.ALIGN_CENTER);

			document.add(Nom);
			document.add(paragraph);

			Paragraph entete = new Paragraph(String.format("%-20s %-30s %8s\n", "Date", "Operation", "Montant"), base);
			String str = "-----------";
			String str2 = "--------------------";
			String str3 = "-----------";
			entete.add(String.format("%-20s %-30s %12s\n", str, str2, str3));

			document.add(entete);

			int taille = lvOperations.getItems().size();
			for (int i = 0; i < taille; i++) {
				Date d = lvOperations.getItems().get(i).dateOp;
				Calendar calendar = Calendar.getInstance();
				calendar.setTime(d);
				if (numMois == calendar.get(Calendar.MONTH) + 1) {
					Paragraph para = new Paragraph(
							String.format("%-20s %-30s %12s\n", lvOperations.getItems().get(i).dateOp,
									lvOperations.getItems().get(i).idTypeOp, lvOperations.getItems().get(i).montant),
							base);
					document.add(para);
				}

			}
		} catch (DocumentException de) {
			de.printStackTrace();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
		document.close();

	}

	@FXML
	private void doDebit() throws DataAccessException, DatabaseConnexionException {

		Operation op = this.om.enregistrerDebit();
		if (op != null) {
			this.updateInfoCompteClient();
			this.validateComponentState(false);
		}
	}

	@FXML
	private void doCredit() throws DataAccessException, DatabaseConnexionException {

		Operation op = this.om.enregistrerCredit();
		if (op != null) {
			this.updateInfoCompteClient();
			this.validateComponentState(false);
		}
	}

	@FXML
	private void doAutre() throws DataAccessException, DatabaseConnexionException {
		Operation op = this.om.enregistrerVirement();
		if (op != null) {
			this.updateInfoCompteClient();
			this.validateComponentState(false);
		}
	}

	/**
	 * Méthode pour définir l'etat des boutons crédit/débit/virement
	 * @param var boolean permettant de désactiver ou non les boutons
	 */
	private void validateComponentState(Boolean var) {
		// Non implémenté => désactivé
		this.btnCredit.setDisable(var);
		this.btnDebit.setDisable(var);
		this.btnVirement.setDisable(var);
	}

	/**
	 * Met à jour la liste olOperation
	 */
	private void updateInfoCompteClient() {

		PairsOfValue<CompteCourant, ArrayList<Operation>> opesEtCompte;

		opesEtCompte = this.om.operationsEtSoldeDunCompte();

		ArrayList<Operation> listeOP;
		this.compteConcerne = opesEtCompte.getLeft();
		listeOP = opesEtCompte.getRight();

		String info;
		info = this.clientDuCompte.nom + "  " + this.clientDuCompte.prenom + "  (id : " + this.clientDuCompte.idNumCli
				+ ")";
		this.lblInfosClient.setText(info);

		info = "Cpt. : " + this.compteConcerne.idNumCompte + "  "
				+ String.format(Locale.ENGLISH, "%12.02f", this.compteConcerne.solde) + "  /  "
				+ String.format(Locale.ENGLISH, "%8d", this.compteConcerne.debitAutorise);
		this.lblInfosCompte.setText(info);

		this.olOperation.clear();
		for (Operation op : listeOP) {
			this.olOperation.add(op);
		}

		this.validateComponentState(false);
	}
}
