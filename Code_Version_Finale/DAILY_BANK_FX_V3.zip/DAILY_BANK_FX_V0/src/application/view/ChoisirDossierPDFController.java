package application.view;

import java.io.File;
import java.net.URL;
import java.util.ResourceBundle;

import application.DailyBankState;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.DirectoryChooser;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

public class ChoisirDossierPDFController  {

	// Etat application
		private DailyBankState dbs;
		private OperationsManagementController omc;

		// Fenêtre physique
		private Stage primaryStage;

		@FXML
		private Button dossier;
		@FXML
		private Button generer;
		@FXML
		private Button annuler;
		@FXML
		private TextField label;
	
	
	public void initContext(Stage _primaryStage, DailyBankState _dbstate) {
		this.primaryStage = _primaryStage;
		this.dbs = _dbstate;
	}
	
		
		public String displayDialog() {			
			this.primaryStage.showAndWait();

			return label.getText();
		}
		
		public void initialize(URL location, ResourceBundle resources) {
		
			generer.setMinWidth(110);
			annuler.setMinWidth(110);
		}
		
		/**
		 * Ouvre une fenetre des dossiers pour choisir le lieu de destination
		 */
		@FXML
		private void doDossier() {
			DirectoryChooser directoryChooser = new DirectoryChooser();
			File selectedDirectory = directoryChooser.showDialog(primaryStage);

			if(selectedDirectory == null){
				
			}else{
			 	label.setText(selectedDirectory.getAbsolutePath());
			}
		
			
		}
		/**
		 * Permet de regler les erreurs si le chemin n'est pas correct ou pas renseigner
		 */
		@FXML
		private void doGenerer() {
			if(label.getText().trim().isEmpty()) {
				Alert fail= new Alert(AlertType.INFORMATION);
				fail.setTitle("Destination non existante");
		        fail.setHeaderText("Erreur");
		        fail.setContentText("Veuillez mettre une destination de fichier en cliquant sur dossier");
		        fail.showAndWait();
		        label.setText("");
			}else {
				primaryStage.close();
			}
		}
		/**
		 * ferme la page
		 */
		@FXML
		private void doAnnuler() {
			label.setText("");
			primaryStage.close();
		}
		
}
