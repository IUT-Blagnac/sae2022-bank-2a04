package application.view;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import application.DailyBankState;
import application.control.ClientsManagement;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import model.data.Client;
import model.data.Employe;
import model.data.VariableClient;

public class ClientsManagementController implements Initializable {

	// Etat application
	private DailyBankState dbs;
	private ClientsManagement cm;

	// Fenêtre physique
	private Stage primaryStage;

	// Données de la fenêtre
	private ObservableList<Client> olc;

	// Manipulation de la fenêtre
	public void initContext(Stage _primaryStage, ClientsManagement _cm, DailyBankState _dbstate) {
		this.cm = _cm;
		this.primaryStage = _primaryStage;
		this.dbs = _dbstate;
		this.configure();
	}

	private void configure() {
		this.primaryStage.setOnCloseRequest(e -> this.closeWindow(e));

		this.olc = FXCollections.observableArrayList();
		this.lvClients.setItems(this.olc);
		this.lvClients.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
		this.lvClients.getFocusModel().focus(-1);
		this.lvClients.getSelectionModel().selectedItemProperty().addListener(e -> this.validateComponentState());
		this.validateComponentState();
	}

	public void displayDialog() {
		doRechercher2(1, "");
		this.primaryStage.showAndWait();
	}

	// Gestion du stage
	private Object closeWindow(WindowEvent e) {
		this.doCancel();
		e.consume();
		return null;
	}

	// Attributs de la scene + actions
	@FXML
	private TextField txtNum;
	@FXML
	private TextField txtNom;
	@FXML
	private TextField txtPrenom;
	@FXML
	private ListView<Client> lvClients;
	@FXML
	private Button btnDesactClient;
	@FXML
	private Button btnModifClient;
	@FXML
	private Button btnComptesClient;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		txtNom.setOnKeyReleased(e -> doRechercher2(1, txtNom.getText()));
		txtPrenom.setOnKeyReleased(e -> doRechercher2(2, txtPrenom.getText()));
		lvClients.setOnMouseClicked(e -> handle(e));
	}
	
	/**
	 * Si un double click est effectuer appel la fonction doComptesClient()
	 * @param mouseEvent
	 */
	public void handle(MouseEvent mouseEvent) {
        if(mouseEvent.getButton().equals(MouseButton.PRIMARY)){
            if(mouseEvent.getClickCount() == 2){
            	doComptesClient();
            }
        }
    }
	/**
	 * Méthode de recherche qui filtre la liste en fonction des mots mis dans txtNom ou txtPrenom
	 * @param var permet de savoir si le nom ou prenom est modifier 1 = nom et 2 = prenom
	 * @param nom soit le nom stocke dans txtNom soit le prenom stocker dans txtPrenom
	 */
	private void doRechercher2(int var, String nom) {
		String deuxiemevar = "";
		ArrayList<Client> listeCli;
		if (var == 1) {
			listeCli = this.cm.getlisteComptes2(nom, deuxiemevar);
		} else {
			listeCli = this.cm.getlisteComptes2(deuxiemevar, nom);
		}
		this.olc.clear();

		for (int i = 0; i < listeCli.size(); i++) {
			if (var == 1) {
				if (listeCli.get(i).nom.startsWith(nom.toUpperCase()))
					this.olc.add(listeCli.get(i));
			} else {
				if (listeCli.get(i).prenom.startsWith(nom.toUpperCase()))
					this.olc.add(listeCli.get(i));
			}

		}
		this.validateComponentState();
	}

	@FXML
	private void doCancel() {
		this.primaryStage.close();
	}



	@FXML
	private void doComptesClient() {
		int selectedIndice = this.lvClients.getSelectionModel().getSelectedIndex();
		if (selectedIndice >= 0) {
			VariableClient.nom = this.lvClients.getItems().get(selectedIndice).nom;
			VariableClient.nom += " " + this.lvClients.getItems().get(selectedIndice).prenom;
			Client client = this.olc.get(selectedIndice);
			this.cm.gererComptesClient(client);
		}
	}

	@FXML
	private void doModifierClient() {

		int selectedIndice = this.lvClients.getSelectionModel().getSelectedIndex();
		if (selectedIndice >= 0) {
			Client cliMod = this.olc.get(selectedIndice);
			Client result = this.cm.modifierClient(cliMod);
			if (result != null) {
				this.olc.set(selectedIndice, result);
			}
		}
	}

	@FXML
	private void doDesactiverClient() {
	}

	@FXML
	private void doNouveauClient() {
		Client client;
		client = this.cm.nouveauClient();
		if (client != null) {
			this.olc.add(client);
		}
	}
/**
 * Désactive ou non des bouttons en fonctions de l'état du clients
 */
	private void validateComponentState() {
		// Non implémenté => désactivé
		this.btnDesactClient.setDisable(true);
		int selectedIndice = this.lvClients.getSelectionModel().getSelectedIndex();
		if (selectedIndice >= 0) {
			this.btnModifClient.setDisable(false);
			this.btnComptesClient.setDisable(false);
		} else {
			this.btnModifClient.setDisable(true);
			this.btnComptesClient.setDisable(true);
		}
	}
//	@FXML
//	private void doRechercher() {
//		int numCompte;
//		try {
//			String nc = this.txtNum.getText();
//			if (nc.equals("")) {
//				numCompte = -1;
//			} else {
//				numCompte = Integer.parseInt(nc);
//				if (numCompte < 0) {
//					this.txtNum.setText("");
//					numCompte = -1;
//				}
//			}
//		} catch (NumberFormatException nfe) {
//			this.txtNum.setText("");
//			numCompte = -1;
//		}
//
//		String debutNom = this.txtNom.getText();
//		String debutPrenom = this.txtPrenom.getText();
//
//		if (numCompte != -1) {
//			this.txtNom.setText("");
//			this.txtPrenom.setText("");
//		} else {
//			if (debutNom.equals("") && !debutPrenom.equals("")) {
//				this.txtPrenom.setText("");
//			}
//		}
//
//		ArrayList<Client> listeCli;
//		listeCli = this.cm.getlisteComptes2(debutNom, debutPrenom);
//
//		this.olc.clear();
//		for (Client cli : listeCli) {
//			this.olc.add(cli);
//		}
//
//		this.validateComponentState();
//	}
}
