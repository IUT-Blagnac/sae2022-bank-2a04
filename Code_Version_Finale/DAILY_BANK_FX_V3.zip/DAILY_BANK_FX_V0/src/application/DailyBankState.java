package application;

import application.tools.ConstantesIHM;
import model.data.AgenceBancaire;
import model.data.Employe;

public class DailyBankState {
	private Employe empAct;
	private AgenceBancaire agAct;
	private boolean isChefDAgence;

	/**
	 * 
	 * @return Un employé
	 */
	public Employe getEmpAct() {
		return this.empAct;
	}
/**
 * Change un employé
 * @param employeActif nouvelle employé
 */
	public void setEmpAct(Employe employeActif) {
		this.empAct = employeActif;
	}
/**
 * 
 * @return L'agenceBancaire
 */
	public AgenceBancaire getAgAct() {
		return this.agAct;
	}

	/**
	 * Modifie l'agence bancaire
	 * @param agenceActive Nouvelle agence
	 */
	public void setAgAct(AgenceBancaire agenceActive) {
		this.agAct = agenceActive;
	}
/**
 * 
 * @return Vrai si il est chef d'agence ou faux si il ne l'est pas
 */
	public boolean isChefDAgence() {
		return this.isChefDAgence;
	}

	/**
	 *Permet de changer le statue d'un employé en chef d'agence ou de l'enlever
	 */
	public void setChefDAgence(boolean isChefDAgence) {
		this.isChefDAgence = isChefDAgence;
	}
/**
 * 
 * @param droitsAccess 
 */
	public void setChefDAgence(String droitsAccess) {
		this.isChefDAgence = false;

		if (droitsAccess.equals(ConstantesIHM.AGENCE_CHEF)) {
			this.isChefDAgence = true;
		}
	}
}
